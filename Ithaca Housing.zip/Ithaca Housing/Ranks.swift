//
//  Ranks.swift
//  Ithaca Housing
//
//  Created by RachelZheng on 23/4/2019.
//  Copyright © 2019 YISU ZHENG. All rights reserved.
//

import Foundation

class Ranks {
    
    var rankName: String
    
    init(rankName: String) {
        self.rankName = rankName
    }
    
}
